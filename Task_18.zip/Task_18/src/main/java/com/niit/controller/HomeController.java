package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
@Autowired
	
	@RequestMapping("/first")
	public String home(){
	System.out.println("In Home");
	return "index";
		}
	@RequestMapping("/header")
	public String header(){
		return "header";
			}
	@RequestMapping("/footer")
	public String signin(){
		
		return "footer";
			}
	@RequestMapping("/signin")
	public String loginin(){
		System.out.println("SingIning");
		return "signin";
			}
	@RequestMapping("/registration")
	public String registration(){
		System.out.println("Registration");
		return "Registration";
			}
	@RequestMapping("/Contact_us")
	public String contact()
	{
		System.out.println("Contact Us");
		return "Contact_us";
	}@RequestMapping("/confreg")
	public String confreg()
	{
		System.out.println("Contact Us");
		return "confreg";
	}
	
	@RequestMapping("/Login_success")
	public String login()
	{
		System.out.println("login");
		return "Login_success";
	}
	@RequestMapping("/Login_failed")
	public String failed()
	{
		System.out.println("failed");
		return "Login_failed";
	}


}
