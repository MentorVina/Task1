package com.config;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {

	public static void main(String[] args) {
		
		HibernateConfig hiber=new HibernateConfig();
		hiber.setRoll_no(1);
		hiber.setName("vina");
		
		SessionFactory sessionfactory=null;
				Configuration configuration=new Configuration();
				
				configuration.configure();
				ServiceRegistry service= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
				sessionfactory=configuration.buildSessionFactory(service);
				
	}

}
